"""LSTM-RNN multi-label continuous emotion recognition for robot speech.

Reference implementation of:
"LSTM-RNN-based method for multi-label learning of continuous emotional
time series in robotic speech interaction" (Decision Making and Analysis, 2026).

Quick start:
    from src import Config, Extractor, LSTMEmotionModel, WindowNormalizer, train
    cfg = Config()
    ext = FeatureExtractor(cfg.audio)
    ...
"""
from .config import Config, AudioConfig, ModelConfig, TrainConfig, DataConfig
from .features import Extractor, WindowNormalizer
from .dataset import (MultiLabelEncoder, WindowDataset, window_dataset_from_files,
                      collate_padded, make_splits)
from .model import LSTMEmotionModel, compute_metrics, temporal_consistency_loss
from .train_eval import train, evaluate, EmotionPredictor

__all__ = [
    "Config", "AudioConfig", "ModelConfig", "TrainConfig", "DataConfig",
    "Extractor", "WindowNormalizer", "MultiLabelEncoder", "WindowDataset",
    "window_dataset_from_files", "collate_padded", "make_splits",
    "LSTMEmotionModel", "compute_metrics", "temporal_consistency_loss",
    "train", "evaluate", "EmotionPredictor",
]
__version__ = "0.1.0"
