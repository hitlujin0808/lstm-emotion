"""Training loop, evaluation, checkpointing and inference API.

Mirrors the protocol of Section 5: speaker-independent split, Macro-F1
early stopping (patience 12), Adam lr=1e-3, reported Table 5-1 / 5-2.
"""
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.optim import Adam, SGD
from torch.utils.data import DataLoader

from .config import Config
from .dataset import WindowDataset, collate_padded
from .features import WindowNormalizer
from .model import (LSTMEmotionModel, compute_metrics, decision_response_latency,
                    decision_stability_index, joint_loss)


def _loader(ds: WindowDataset, batch_size: int, shuffle: bool,
            num_workers: int = 0) -> DataLoader:
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle,
                      collate_fn=collate_padded, num_workers=num_workers,
                      pin_memory=False)


def train(cfg: Config, train_ds: WindowDataset, val_ds: WindowDataset,
          device: str = "cpu", checkpoint_dir: str = "checkpoints",
          verbose: bool = True) -> LSTMEmotionModel:
    device = _resolve_device(device)
    model = LSTMEmotionModel(cfg.model).to(device)

    # input_dim auto-detection
    if cfg.model.input_dim != cfg.audio.frame_length:
        pass

    opt = _optimizer(model, cfg.train)
    pos_weight = _pos_weight(train_ds, device, cfg.train.pos_weight)

    best_macro = -1.0
    best_state: dict = {}
    no_improve = 0

    for epoch in range(1, cfg.train.epochs + 1):
        model.train()
        running = {"loss": 0.0, "cls": 0.0, "tc": 0.0, "n": 0}
        for X, Y, L in _loader(train_ds, cfg.train.batch_size, shuffle=True):
            X, Y, L = X.to(device), Y.to(device), L.to(device)
            mask = _length_mask(L, X.shape[1], device)
            opt.zero_grad()
            probs = model(X, L)
            logits = _logits(model, X, L)  # type: ignore[attr-defined]
            loss, parts = joint_loss(logits, Y, probs, cfg.train,
                                     pos_weight=pos_weight, mask=mask)
            loss.backward()
            if cfg.train.clip_grad > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(),
                                               cfg.train.clip_grad)
            opt.step()
            n = int(mask.sum())
            running["loss"] += float(loss.detach()) * n
            running["cls"] += parts["cls"] * n
            running["tc"] += parts["tc"] * n
            running["n"] += n

        # validation
        val_m = evaluate(model, val_ds, cfg, device)
        tr_loss = running["loss"] / max(running["n"], 1)
        if verbose:
            print(f"[epoch {epoch:03d}] train_loss={tr_loss:.4f} "
                  f"val_macro_f1={val_m['macro_f1']:.4f} "
                  f"val_hamming={val_m['hamming_loss']:.4f}")

        if val_m["macro_f1"] > best_macro + cfg.train.min_delta:
            best_macro = val_m["macro_f1"]
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
            _save(model, cfg, Path(checkpoint_dir) / "best.pt",
                  extra={"epoch": epoch, "macro_f1": best_macro})
        else:
            no_improve += 1
            if no_improve >= cfg.train.patience:
                if verbose:
                    print(f"Early stopping at epoch {epoch} "
                          f"(best Macro-F1 {best_macro:.4f}).")
                break

    if best_state:
        model.load_state_dict(best_state)
    return model


@torch.no_grad()
def evaluate(model: LSTMEmotionModel, ds: WindowDataset, cfg: Config,
             device: str, threshold: Optional[float] = None
             ) -> Dict[str, float]:
    device = _resolve_device(device)
    model.eval()
    th = threshold if threshold is not None else cfg.model.threshold
    agg = {"micro_f1": [], "macro_f1": [], "hamming_loss": [],
           "avg_precision": [], "dsi": [], "drl": []}
    for X, Y, L in _loader(ds, cfg.train.batch_size, shuffle=False):
        X, Y, L = X.to(device), Y.to(device), L.to(device)
        mask = _length_mask(L, X.shape[1], device)
        probs = model(X, L)
        m = compute_metrics(probs, Y, threshold=th, mask=mask)
        for k in ("micro_f1", "macro_f1", "hamming_loss", "avg_precision"):
            agg[k].append(m[k])
        # DSI / DRL: concatenate windows into one dialogue sequence
        for b in range(X.shape[0]):
            end = int(L[b])
            p_seq = probs[b, :end, :].cpu()
            y_seq = Y[b, :end, :].cpu()
            agg["dsi"].append(decision_stability_index(p_seq))
            agg["drl"].append(decision_response_latency(p_seq, y_seq, th))
    out = {k: float(np.mean(v)) for k, v in agg.items() if v}
    if agg["dsi"]:
        out["dsi"] = float(np.mean(agg["dsi"]))
        out["drl"] = float(np.nanmean(agg["drl"]))
    return out


def _logits(model, X, L):
    """Recompute logits (pre-sigmoid) for the loss."""
    # access the raw linear head output by re-running LSTM + head
    if hasattr(model, "_raw_logits"):
        return model._raw_logits
    # patch: register a hook-style helper on the model instance
    import torch.nn as nn
    lstm_out, _ = model.lstm(X)
    if isinstance(lstm_out, nn.utils.rnn.PackedSequence):
        lstm_out, _ = nn.utils.rnn.pad_packed_sequence(lstm_out, batch_first=True)
    lstm_out = model.drop(lstm_out)
    return model.head(lstm_out)


def _length_mask(lengths: torch.Tensor, max_len: int, device: str) -> torch.Tensor:
    ar = torch.arange(max_len, device=device).unsqueeze(0)
    return (ar < lengths.unsqueeze(1)).float()


def _pos_weight(ds: WindowDataset, device: str,
                manual: Optional[float]) -> Optional[torch.Tensor]:
    if manual is not None:
        return torch.full((len(ds.targets[0][0]),), manual, device=device)
    # count positives per class over the dataset
    tot = torch.zeros(len(ds.targets[0][0]), dtype=torch.float32)
    cnt = torch.zeros_like(tot)
    for t in ds.targets:
        tot += t.sum(dim=0)
        cnt += (t > 0).sum(dim=0)
    neg = cnt - tot
    pw = neg / tot.clamp(min=1.0)
    return pw.to(device)


def _optimizer(model: LSTMEmotionModel, cfg: TrainConfig):
    if cfg.optimizer == "sgd":
        return SGD(model.parameters(), lr=cfg.lr, momentum=0.9,
                   weight_decay=cfg.weight_decay)
    return Adam(model.parameters(), lr=cfg.lr,
                weight_decay=cfg.weight_decay)


def _resolve_device(device: str) -> str:
    if device == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return device


def _save(model: LSTMEmotionModel, cfg: Config, path: Path, extra: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"model_state": model.state_dict(),
                "config": _cfg_to_dict(cfg),
                "model_cfg": cfg.model.output_names,
                **extra}, path)


def _cfg_to_dict(cfg: Config) -> dict:
    import dataclasses
    out = {}
    for f in dataclasses.fields(cfg):
        v = getattr(cfg, f.name)
        out[f.name] = dataclasses.asdict(v) if dataclasses.is_dataclass(v) else v
    return out


# --------------------------- inference API --------------------------
class EmotionPredictor:
    """Online / streaming inference matching Section 3.6.

    Buffers incoming speech in 1 s hops, updates the probability vector
    per window, applies optional exponential smoothing (Section 3.2.6,
    prediction-phase smoothing).
    """

    def __init__(self, model: LSTMEmotionModel, normalizer: WindowNormalizer,
                 extractor, cfg: Config, smooth_alpha: float = 0.0):
        self.model = model.eval()
        self.normalizer = normalizer
        self.extractor = extractor
        self.cfg = cfg
        self.alpha = smooth_alpha
        self._prev: Optional[np.ndarray] = None
        self.class_names = cfg.model.output_names

    @torch.no_grad()
    def predict_window(self, audio_segment: np.ndarray) -> Dict[str, float]:
        vec = self.extractor.from_audio(audio_segment)
        vec = self.normalizer(vec)
        x = torch.from_numpy(vec[None, None, :])  # (1,1,D)
        probs = self.model(x)[0, 0, :].cpu().numpy()
        if self.alpha > 0 and self._prev is not None:
            probs = self.alpha * probs + (1 - self.alpha) * self._prev
        self._prev = probs
        return dict(zip(self.class_names, probs.tolist()))

    def predict_labels(self, probs: Dict[str, float]) -> List[str]:
        th = self.cfg.model.threshold
        return [k for k, v in probs.items() if v >= th]
