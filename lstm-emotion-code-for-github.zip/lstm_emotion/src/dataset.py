"""Windowing, dataset, multi-label target encoding and data splits.

Implements Section 3.2.2 (continuous time-window construction: fixed-length
2 s windows, 1 s hop) and Section 4.2 (length standardisation, normalisation,
speaker-independent leave-one-session-out split).

NOTE ON GROUND TRUTH: IEMOCAP / MSP-IMPROV / RAVDESS ship with **single**
categorical labels per utterance (e.g. "angry", "happy"), while this paper
formulates emotion as a **multi-label** problem (Section 2.3, 3.2.5). The
paper does not publish its multi-label annotation protocol, so this
reference implementation converts the single label into a one-hot vector
and treats it as a degenerate multi-label target. A real deployment must
replace ``MultiLabelEncoder.encode`` with the paper's own annotation or a
human-labelled multi-label scheme.
"""
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

from .config import AudioConfig, DataConfig
from .features import Extractor, WindowNormalizer


class MultiLabelEncoder:
    """Map emotion label strings to multi-hot vectors.

    ``neutral`` is included so the model can express "no strong emotion",
    matching Section 3.2.5 (the label set covers joy/sad/anger/fear/surprise
    plus confusion/frustration/interest/trust).
    """

    def __init__(self, class_names: Sequence[str]):
        self.class_names = list(class_names)
        self.idx = {n: i for i, n in enumerate(self.class_names)}
        self.n_classes = len(self.class_names)

    def encode(self, label: str) -> np.ndarray:
        """One-hot encode a categorical label -> degenerate multi-label."""
        if label not in self.idx:
            raise ValueError(f"Unknown emotion label: {label!r}. "
                             f"Known: {self.class_names}")
        y = np.zeros(self.n_classes, dtype=np.float32)
        y[self.idx[label]] = 1.0
        return y

    def decode(self, probs: np.ndarray, threshold: float = 0.5) -> List[str]:
        return [n for n, p in zip(self.class_names, probs) if p >= threshold]

    @classmethod
    def default(cls, names: Optional[Sequence[str]] = None) -> "MultiLabelEncoder":
        if names is None:
            names = ["neutral", "happy", "sad", "angry", "fearful",
                     "surprised", "confused", "frustrated",
                     "interested", "trust"]
        return cls(names)


class WindowDataset(Dataset):
    """Sliding-window dataset yielding (feature_sequence, multi_label_target).

    ``X`` has shape ``(T, D)`` and is left-padded with zeros when an
    utterance is shorter than ``window_s``. ``lengths`` reports the true
    number of valid windows so packed sequences / masking can be used.
    """

    def __init__(self, windows: Sequence[np.ndarray], targets: Sequence[np.ndarray],
                 lengths: Sequence[int]):
        self.windows = [torch.from_numpy(np.asarray(w, dtype=np.float32))
                        for w in windows]
        self.targets = [torch.from_numpy(np.asarray(t, dtype=np.float32))
                        for t in targets]
        self.lengths = np.asarray(lengths, dtype=np.int64)

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, i: int) -> Tuple[torch.Tensor, torch.Tensor, int]:
        return self.windows[i], self.targets[i], int(self.lengths[i])


def collate_padded(batch):
    """Pad variable-length window sequences to the max length in the batch."""
    X, Y, L = zip(*batch)
    lengths = torch.tensor(L, dtype=torch.long)
    Xp = torch.nn.utils.rnn.pad_sequence(X, batch_first=True, padding_value=0.0)
    Yp = torch.nn.utils.rnn.pad_sequence(Y, batch_first=True, padding_value=0.0)
    return Xp, Yp, lengths


def build_windows(audio_path: str, labels: Sequence[Tuple[float, float, str]],
                  extractor: Extractor, window_s: float, hop_s: float,
                  normalizer: Optional[WindowNormalizer] = None,
                  max_duration_s: float = 30.0) -> Tuple[List[np.ndarray],
                                                          List[np.ndarray],
                                                          List[int]]:
    """Split one utterance into overlapping time windows with multi-label targets.

    Returns ``(windows, targets, lengths)`` where ``windows[k]`` is a
    ``(T_k, D)`` array and ``targets[k]`` is ``(T_k, C)``.
    """
    y, sr = __import__("librosa").load(audio_path, sr=extractor.sr, mono=True)
    if len(y) / sr > max_duration_s:
        y = y[:int(max_duration_s * sr)]
    total_s = len(y) / sr

    wins: list[np.ndarray] = []
    targs: list[np.ndarray] = []
    lens: list[int] = []
    enc = MultiLabelEncoder.default()
    # re-resolve encoder via module import (avoid circular)
    from .dataset import MultiLabelEncoder  # local import for clarity

    start = 0.0
    while start < total_s - window_s / 2:
        end = min(start + window_s, total_s)
        seg = y[int(start * sr):int(end * sr)]
        if len(seg) < 0.1 * sr:
            break
        vec = extractor.from_audio(seg)
        if normalizer is not None:
            vec = normalizer(vec)
        # aggregate labels active inside this window
        target = np.zeros(len(MultiLabelEncoder.default().class_names),
                          dtype=np.float32)
        for t0, t1, lab in labels:
            if t0 < end and t1 > start:
                idx = MultiLabelEncoder.default().idx.get(lab)
                if idx is not None:
                    target[idx] = 1.0
        wins.append(vec[None, :])  # (1, D)
        targs.append(target[None, :])  # (1, C)
        lens.append(1)
        start += hop_s
        if end >= total_s:
            break

    if not wins:  # utterance shorter than one window: zero-pad once
        vec = extractor.from_audio(y) if len(y) else np.zeros(extractor.out_dim)
        if normalizer is not None:
            vec = normalizer(vec)
        target = np.zeros(len(MultiLabelEncoder.default().class_names),
                          dtype=np.float32)
        for t0, t1, lab in labels:
            idx = MultiLabelEncoder.default().idx.get(lab)
            if idx is not None:
                target[idx] = 1.0
        wins.append(vec[None, :])
        targs.append(target[None, :])
        lens.append(1)

    # merge consecutive 1-window slices into a single sequence
    if len(wins) > 1:
        X = np.concatenate(wins, axis=0)
        Y = np.concatenate(targs, axis=0)
        return [X], [Y], [X.shape[0]]
    return wins, targs, lens


# ------------------------- split helpers -------------------------
def _iemocap_sessions(root: str) -> Dict[str, List[Path]]:
    """Return {session_name: [utterance wav paths]} for IEMOCAP."""
    root = Path(root)
    sessions = {}
    for ses in sorted((root / "IEMOCAP_full_release").iterdir()) \
            if (root / "IEMOCAP_full_release").exists() else []:
        if ses.is_dir() and ses.name.lower().startswith("session"):
            wavs = sorted((ses / "sentences" / "wav").rglob("*.wav")) \
                if (ses / "sentences" / "wav").exists() else sorted(ses.rglob("*.wav"))
            if wavs:
                sessions[ses.name] = wavs
    if not sessions:  # generic flat layout: one directory per dataset
        for d in sorted(root.iterdir()):
            if d.is_dir() and any(d.glob("**/*.wav")):
                sessions[d.name] = sorted(d.rglob("*.wav"))
    return sessions


def make_splits(cfg: DataConfig,
                label_map: Optional[Dict[str, str]] = None) -> Tuple[
                    List[Path], List[Path], List[Path]]:
    """Session-level split. Default = leave-one-session-out, Session 5 test."""
    sessions = _iemocap_sessions(cfg.root)
    if not sessions:
        raise FileNotFoundError(
            f"No audio found under {cfg.root}. See README.md for the "
            "expected IEMOCAP directory layout and download instructions.")
    test = sessions.get(cfg.test_session, list(sessions.values())[-1])
    train, val = [], []
    for name, wavs in sessions.items():
        if name == cfg.test_session:
            continue
        n = int(len(wavs) * cfg.val_ratio)
        val += wavs[:max(n, 1)]
        train += wavs[n:]
    return train, val, test


def window_dataset_from_files(files: Sequence[Path],
                             extractor: Extractor,
                             window_s: float, hop_s: float,
                             normalizer: Optional[WindowNormalizer] = None,
                             label_map: Optional[Dict[str, str]] = None,
                             ) -> WindowDataset:
    """Construct a WindowDataset from audio files + a label map.

    ``label_map``: ``{stem: "emotion"}``. If None, stems are parsed as
    IEMOCAP emotion category names (e.g. ``Ses01F_impro01_F001`` -> ``ang``).
    """
    all_w: list[np.ndarray] = []
    all_t: list[np.ndarray] = []
    all_l: list[int] = []
    default = MultiLabelEncoder.default()
    for f in files:
        lab = _resolve_label(f, label_map, default)
        labels = [(0.0, 9e9, lab)]  # whole utterance
        w, t, l = build_windows(str(f), labels, extractor, window_s, hop_s,
                               normalizer)
        all_w += w
        all_t += t
        all_l += l
    return WindowDataset(all_w, all_t, all_l)


_IEMOCAP_CAT = {  # emotion category -> canonical label
    "ang": "angry", "hap": "happy", "exc": "happy", "sad": "sad",
    "fru": "frustrated", "fea": "fearful", "sur": "surprised",
    "neu": "neutral", "dis": "sad", "oth": "neutral",
}


def _resolve_label(path: Path, label_map, encoder: MultiLabelEncoder) -> str:
    stem = path.stem
    if label_map and stem in label_map:
        return label_map[stem]
    # IEMOCAP naming: *_<cat>.wav or *_<cat><digit>.wav  (e.g. F001, M001)
    cand = stem.split("_")[-1].lower()
    cand = "".join(ch for ch in cand if not ch.isdigit())
    cand = cand[:3]
    if cand in _IEMOCAP_CAT and _IEMOCAP_CAT[cand] in encoder.idx:
        return _IEMOCAP_CAT[cand]
    if cand in encoder.idx:
        return cand
    raise ValueError(f"Cannot resolve emotion label for {path.name!r}; "
                     f"pass an explicit --label-map CSV.")
