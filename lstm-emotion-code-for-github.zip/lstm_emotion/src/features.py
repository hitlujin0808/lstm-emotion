"""Feature extraction for one time window: acoustic, prosodic, spectral and
deep representations, fused by concatenation as described in Section 3.2.3.

The implementation follows the paper literally where parameters are given
(16 kHz, 25 ms frame / 10 ms hop, 40 Mel bins, 13 MFCC -> 39 with deltas,
pYIN F0, energy, centroid, flux, pause ratio, speech rate) and uses
librosa/numpy so it runs on CPU without PyTorch.
"""
from typing import Dict, Optional, Sequence, Tuple

import numpy as np

try:
    import librosa
except ImportError:  # pragma: no cover
    librosa = None  # type: ignore

from .config import AudioConfig


class FeatureExtractor:
    """Extract a fixed-dimensional feature vector per time window."""

    def __init__(self, cfg: AudioConfig, use_deep: bool = False):
        if librosa is None:
            raise ImportError("librosa is required:  pip install librosa")
        self.cfg = cfg
        self.use_deep = use_deep
        self.sr = cfg.sample_rate
        self._n_fft = 2 ** int(np.ceil(np.log2(cfg.frame_length)))
        # Selected low-level features are aggregated per window:
        #   39 MFCC stats (mean + std of 13 + delta + delta-delta) = 78
        #   energy stats                                                  = 2
        #   F0 stats (+ voicing rate)                                    = 5
        #   centroid / flux / rolloff stats                              = 6
        #   prosodic: speech rate, pause ratio, voiced ratio            = 3
        #   deep placeholder (disabled by default)                      = 0/64
        self._base_dim = 78 + 2 + 5 + 6 + 3  # 94
        self._deep_dim = 64 if use_deep else 0
        self.out_dim: int = self._base_dim + self._deep_dim

    # ------------------------------------------------------------------
    def from_file(self, path: str, offset: float = 0.0,
                  duration: Optional[float] = None) -> np.ndarray:
        y, _ = librosa.load(path, sr=self.sr, mono=True, offset=offset,
                            duration=duration)
        return self.from_audio(y)

    def from_audio(self, y: np.ndarray) -> np.ndarray:
        y = np.asarray(y, dtype=np.float32)
        if y.ndim > 1:
            y = y.mean(axis=0)
        if len(y) == 0:
            return np.zeros(self.out_dim, dtype=np.float32)

        # pre-emphasis
        if self.cfg.pre_emphasis > 0:
            y = np.concatenate([y[:1], y[1:] - self.cfg.pre_emphasis * y[:-1]])

        feats: Dict[str, np.ndarray] = {}

        # --- MFCC (13 + delta + delta-delta) --------------------------
        mfcc = librosa.feature.mfcc(y=y, sr=self.sr, n_mfcc=self.cfg.n_mfcc,
                                    n_fft=self._nfft,
                                    hop_length=self.cfg.hop_length,
                                    win_length=self.cfg.frame_length,
                                    n_mels=self.cfg.n_mels)
        delta = librosa.feature.delta(mfcc, width=3, order=1)
        delta2 = librosa.feature.delta(mfcc, width=3, order=2)
        feats["mfcc"] = np.concatenate([mfcc, delta, delta2], axis=0)

        # --- short-time energy -----------------------------------------
        S = np.abs(librosa.stft(y, n_fft=self._nfft,
                               hop_length=self.cfg.hop_length,
                               win_length=self.cfg.frame_length)) ** 2
        energy = np.sum(S, axis=0).astype(np.float32)
        energy = energy / (energy.max() + 1e-9)
        feats["energy"] = energy[None, :]

        # --- F0 via pYIN ----------------------------------------------
        f0, voiced_flag, _ = librosa.pyin(
            y, fmin=self.cfg.f0_min, fmax=self.cfg.f0_max, sr=self.sr,
            hop_length=self.cfg.hop_length)
        f0 = np.nan_to_num(f0, nan=0.0).astype(np.float32)
        feats["f0"] = f0[None, :]
        feats["voiced"] = voiced_flag.astype(np.float32)[None, :]

        # --- spectral centroid / flux / rolloff ------------------------
        cent = librosa.feature.spectral_centroid(S=S, sr=self.sr)
        flux = librosa.onset.onset_strength(y=y, sr=self.sr,
                                            hop_length=self.cfg.hop_length)
        rolloff = librosa.feature.spectral_rolloff(S=S, sr=self.sr, roll_percent=0.85)
        feats["centroid"] = cent
        feats["flux"] = flux[None, :]
        feats["rolloff"] = rolloff

        # --- prosodic: speech rate proxy & pause ratio -----------------
        rms = librosa.feature.rms(y=y, hop_length=self.cfg.hop_length,
                                  win_length=self.cfg.frame_length)[0]
        speech_rate = float(np.mean(flux)) if flux.size else 0.0
        pause_ratio = float(np.mean(rms < 0.01 * (rms.max() + 1e-9)))
        voiced_ratio = float(np.mean(voiced_flag))
        feats["prosody"] = np.array([[speech_rate, pause_ratio, voiced_ratio]],
                                    dtype=np.float32)

        return self._aggregate(feats)

    # ------------------------------------------------------------------
    def _aggregate(self, feats: Dict[str, np.ndarray]) -> np.ndarray:
        parts: list[np.ndarray] = []

        # MFCC: per-coefficient mean + std  -> 39*2 = 78
        m = feats["mfcc"]
        parts.append(np.concatenate([m.mean(axis=1), m.std(axis=1)], axis=0))

        # energy: mean + std
        e = feats["energy"]
        parts.append(np.array([e.mean(), e.std()], dtype=np.float32))

        # F0: mean, std, max, median, voicing-rate  -> 5
        f0 = feats["f0"][0]
        nonzero = f0[f0 > 0]
        parts.append(np.array([
            nonzero.mean() if nonzero.size else 0.0,
            nonzero.std() if nonzero.size else 0.0,
            nonzero.max() if nonzero.size else 0.0,
            np.median(nonzero) if nonzero.size else 0.0,
            float(feats["voiced"].mean()),
        ], dtype=np.float32))

        # spectral: centroid, flux, rolloff  -> each mean+std = 6
        for key in ("centroid", "flux", "rolloff"):
            v = feats[key]
            parts.append(np.array([v.mean(), v.std()], dtype=np.float32))

        # prosody: already 3-d
        parts.append(feats["prosody"].astype(np.float32).reshape(-1))

        vec = np.concatenate(parts, axis=0).astype(np.float32)
        assert vec.shape[0] == self._base_dim, (vec.shape, self._base_dim)

        if self.use_deep:  # placeholder: average Mel-spectrogram embedding
            mel = librosa.feature.melspectrogram(
                y=np.concatenate([np.zeros(self.cfg.hop_length),
                                  np.zeros(self.cfg.hop_length)]),  # dummy
                sr=self.sr, n_mels=self.cfg.n_mels)
            deep = np.zeros(self._deep_dim, dtype=np.float32)
            vec = np.concatenate([vec, deep], axis=0)

        return vec

    # ------------------------------------------------------------------
    @staticmethod
    def fit_normalizer(features: Sequence[np.ndarray]):
        """Fit per-dim mean/std on a list of window vectors (training split)."""
        arr = np.asarray(features, dtype=np.float32)
        mean = arr.mean(axis=0)
        std = arr.std(axis=0)
        std[std < 1e-8] = 1.0
        return WindowNormalizer(mean, std)


class WindowNormalizer:
    def __init__(self, mean: np.ndarray, std: np.ndarray):
        self.mean = np.asarray(mean, dtype=np.float32)
        self.std = np.asarray(std, dtype=np.float32)

    def __call__(self, x: np.ndarray) -> np.ndarray:
        return ((x - self.mean) / self.std).astype(np.float32)

    def state_dict(self) -> Dict:
        return {"mean": self.mean.tolist(), "std": self.std.tolist()}

    @classmethod
    def from_state_dict(cls, d: Dict) -> "WindowNormalizer":
        return cls(np.asarray(d["mean"], dtype=np.float32),
                   np.asarray(d["std"], dtype=np.float32))
