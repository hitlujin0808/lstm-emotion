"""Baseline models for the comparison of Table 4-1 / Table 5-1.

Implements SVM, Random Forest, MLP, vanilla RNN, single-label LSTM, CNN,
BiLSTM, CNN-LSTM and CNN-BiLSTM-Attention so that the reported comparison
is reproducible. All take the **same** windowed feature matrices as input.
"""
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from sklearn.base import clone
from sklearn.linear_model import SGDClassifier as SkSVM
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.preprocessing import StandardScaler

from .config import AudioConfig, TrainConfig
from .dataset import WindowDataset
from .features import FeatureExtractor, WindowNormalizer


# ------------------------- sklearn baselines -------------------------
class SklearnBaseline:
    """SVM / RF / MLP operating on window-mean feature vectors.

    Multi-output wrapper gives independent per-label classifiers, so the
    comparison is multi-label (BCE / one-vs-rest), matching Section 4.3.
    """

    def __init__(self, kind: str = "svm", **kw):
        assert kind in ("svm", "rf", "mlp")
        self.kind = kind
        if kind == "svm":
            base = SkSVM(loss="log_loss", max_iter=2000, **kw)
        elif kind == "rf":
            base = RandomForestClassifier(n_estimators=200, **kw)
        else:
            base = MLPClassifier(hidden_layer_sizes=(128, 64),
                                 max_iter=2000, **kw)
        self.clf = MultiOutputClassifier(base)
        self.scaler = StandardScaler()

    def fit(self, ds: WindowDataset):
        X, Y = self._flat(ds)
        self.clf.fit(self.scaler.fit_transform(X), Y)
        return self

    def predict_proba(self, ds: WindowDataset) -> np.ndarray:
        X, _ = self._flat(ds)
        # MultiOutputClassifier returns list of arrays; stack class=1 probs
        proba = np.column_stack([c[:, 1] for c in self.clf.predict_proba(self.scaler.transform(X))])
        return proba

    def _flat(self, ds):
        Xs, Ys = [], []
        for w, t, _ in ds:
            Xs.append(w.reshape(-1, w.shape[-1]).numpy())
            Ys.append(t.reshape(-1, t.shape[-1]).numpy())
        return np.vstack(Xs), np.vstack(Ys).astype(int)


# ------------------------- deep-learning baselines -------------------------
class _RNNBase(nn.Module):
    def __init__(self, in_dim: int, hidden: int, out_dim: int,
                 num_layers: int = 1, bidirectional: bool = False,
                 dropout: float = 0.3, cnn: bool = False,
                 attention: bool = False):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(in_dim, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(),
        ) if cnn else nn.Identity()
        d_in = 64 if cnn else in_dim
        self.rnn = nn.LSTM(d_in, hidden, num_layers=num_layers,
                           bidirectional=bidirectional, batch_first=True,
                           dropout=dropout if num_layers > 1 else 0.0)
        self.attn = nn.Linear(hidden * (2 if bidirectional else 1),
                              hidden * (2 if bidirectional else 1)) \
            if attention else None
        self.head = nn.Linear(hidden * (2 if bidirectional else 1), out_dim)
        self._out_dim = out_dim

    def forward(self, x, lengths):
        if not isinstance(self.cnn, nn.Identity):
            x = self.cnn(x.transpose(1, 2)).transpose(1, 2)
        packed = nn.utils.rnn.pack_padded_sequence(
            x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out, _ = self.rnn(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(out, batch_first=True)
        if self.attn is not None:
            w = torch.softmax(self.attn(out), dim=1)
            out = (out * w).sum(dim=1)
        return torch.sigmoid(self.head(out))


def make_baseline(name: str, in_dim: int, out_dim: int,
                  hidden: int = 128) -> nn.Module:
    name = name.lower()
    if name == "rnn":
        return _RNNBase(in_dim, hidden, out_dim, bidirectional=False)
    if name == "lstm":
        return _RNNBase(in_dim, hidden, out_dim, bidirectional=False)
    if name == "bilstm":
        return _RNNBase(in_dim, hidden, out_dim, bidirectional=True)
    if name == "cnn":
        class _CNN(nn.Module):
            def __init__(self):
                super().__init__()
                self.net = nn.Sequential(
                    nn.Conv1d(in_dim, 64, 3, padding=1), nn.ReLU(),
                    nn.Conv1d(64, 64, 3, padding=1), nn.ReLU(),
                    nn.AdaptiveAvgPool1d(1), nn.Flatten(),
                    nn.Linear(64, out_dim))
                self.s = torch.sigmoid

            def forward(self, x, lengths):
                return self.s(self.net(x.transpose(1, 2)))
        return _CNN()
    if name == "cnn-lstm":
        return _RNNBase(in_dim, hidden, out_dim, cnn=True, bidirectional=False)
    if name == "cnn-bilstm-attention":
        return _RNNBase(in_dim, hidden, out_dim, cnn=True, bidirectional=True,
                        attention=True)
    raise ValueError(f"Unknown baseline: {name}")
