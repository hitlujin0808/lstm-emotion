"""Configuration schema and default values for the LSTM-RNN multi-label
continuous emotion recognition pipeline.

All numbers are taken verbatim from the paper:
* Section 4.2 (data pre-processing): 16 kHz resampling, mono, pre-emphasis
  coefficient 0.97, 25 ms frames / 10 ms hop, 40-d Mel spectrogram,
  13-d MFCC (+ delta + delta-delta -> 39), pitch (F0) via pYIN, energy,
  spectral centroid / flux, pause ratio, speech rate; per-feature z-score
  normalisation fitted on the training split.
* Section 3.2.4: 2-layer unidirectional stacked LSTM, hidden size 128,
  dropout 0.3 between layers, batch size 32, Adam (lr=1e-3), BCEWithLogits
  + temporal-consistency loss, lambda_tc=0.3 (ablation optimum, Fig. 5-3b).
* Section 4.4: threshold 0.5; leave-one-session-out on IEMOCAP (Session 5
  as test set in the reported Table 5-1), speaker-independent.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class AudioConfig:
    sample_rate: int = 16000
    mono: bool = True
    pre_emphasis: float = 0.97
    frame_ms: float = 25.0
    hop_ms: float = 10.0
    n_mels: int = 40
    n_mfcc: int = 13
    f0_min: float = 50.0
    f0_max: float = 500.0
    max_duration_s: float = 30.0  # truncate long utterances; zero-pad shorter
    trim_silence_top_db: int = 30
    norm: str = "zscore"  # "zscore" | "minmax" | "none"

    @property
    def frame_length(self) -> int:
        return int(round(self.frame_ms / 1000.0 * self.sample_rate))

    @property
    def hop_length(self) -> int:
        return int(round(self.hop_ms / 1000.0 * self.sample_rate))


@dataclass
class ModelConfig:
    input_dim: int = 128  # set automatically by FeatureExtractor.out_dim
    hidden_dim: int = 128
    num_layers: int = 2
    dropout: float = 0.3
    bidirectional: bool = False  # paper: online use -> unidirectional
    output_names: List[str] = field(default_factory=lambda: [
        "neutral", "happy", "sad", "angry", "fearful", "surprised",
        "confused", "frustrated", "interested", "trust",
    ])
    threshold: float = 0.5  # per-class, may be a dict in extended configs


@dataclass
class TrainConfig:
    epochs: int = 100
    batch_size: int = 32
    lr: float = 1e-3
    weight_decay: float = 1e-5
    optimizer: str = "adam"  # "adam" | "sgd"
    pos_weight: Optional[float] = None  # auto = (N_neg/N_pos) per class
    lambda_tc: float = 0.3  # temporal consistency weight (Fig. 5-3b optimum)
    tc_mode: str = "mse"  # "mse" | "kl" | "cosine"
    patience: int = 12  # early stopping on validation Macro-F1
    min_delta: float = 1e-4
    clip_grad: float = 5.0
    seed: int = 42


@dataclass
class DataConfig:
    root: str = "data/raw"
    cache_dir: str = "data/processed"
    splits: str = "iemocap_loso"  # "iemocap_loso" | "msp_improv" | "ravdess"
    test_session: str = "Session5"  # leave-one-session-out
    val_ratio: float = 0.1  # of training sessions, session-level
    speaker_independent: bool = True
    window_s: float = 2.0  # continuous time window (Sec. 3.2.2)
    window_hop_s: float = 1.0  # 50% overlap between adjacent windows


@dataclass
class Config:
    audio: AudioConfig = field(default_factory=AudioConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    data: DataConfig = field(default_factory=DataConfig)

    @classmethod
    def from_dict(cls, d: Dict) -> "Config":
        cfg = cls()
        for k, v in d.items():
            if not hasattr(cfg, k):
                raise ValueError(f"Unknown config section: {k}")
            section = getattr(cfg, k)
            if isinstance(v, dict):
                for sk, sv in v.items():
                    if not hasattr(section, sk):
                        raise ValueError(f"Unknown config key: {k}.{sk}")
                    setattr(section, sk, sv)
            else:
                setattr(cfg, k, v)
        return cfg
