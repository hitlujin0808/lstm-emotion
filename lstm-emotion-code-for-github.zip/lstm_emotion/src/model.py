"""LSTM-RNN multi-label temporal model, losses and metrics.

Equations (1)-(4) in the paper:
    h_t = LSTM(x_t, h_{t-1})                        (1) temporal encoding
    p_{t,c} = sigmoid(W h_t + b)_c                   (2) multi-label prediction
    L_tc = (1/(T-1)) * sum_t ||p_t - p_{t-1}||^2     (3) per-label temporal MSE
    L   = L_cls + lambda_tc * L_tc                   (4) joint loss

Metrics (Section 4.4): Micro-F1, Macro-F1, Hamming Loss,
Label-Ranking Average Precision, plus DSI (Decision Stability Index) and
DRL (Decision Response Latency), defined exactly as in the text.
"""
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
from sklearn.metrics import f1_score, hamming_loss, label_ranking_average_precision_score

from .config import ModelConfig, TrainConfig


class LSTMEmotionModel(nn.Module):
    """Stacked unidirectional LSTM -> linear -> sigmoid (multi-label)."""

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg
        self.n_classes = len(cfg.output_names)
        self.lstm = nn.LSTM(
            input_size=cfg.input_dim,
            hidden_size=cfg.hidden_dim,
            num_layers=cfg.num_layers,
            batch_first=True,
            bidirectional=cfg.bidirectional,
            dropout=cfg.dropout if cfg.num_layers > 1 else 0.0,
        )
        self.drop = nn.Dropout(cfg.dropout) if cfg.num_layers == 1 else nn.Identity()
        self.head = nn.Linear(cfg.hidden_dim * (2 if cfg.bidirectional else 1),
                              self.n_classes)
        self.act = nn.Sigmoid()
        self._init_weights()

    def _init_weights(self) -> None:
        for name, p in self.named_parameters():
            if "weight" in name and p.dim() >= 2:
                nn.init.xavier_uniform_(p)
            elif "bias" in name:
                nn.init.zeros_(p)

    def forward(self, x: torch.Tensor, lengths: Optional[torch.Tensor] = None
                ) -> torch.Tensor:
        """x: (B, T, D) padded; returns p: (B, T, C)."""
        if lengths is not None and self.training is False:
            packed = nn.utils.rnn.pack_padded_sequence(
                x, lengths.cpu(), batch_first=True, enforce_sorted=False)
            out, _ = self.lstm(packed)
            out, _ = nn.utils.rnn.pad_packed_sequence(out, batch_first=True)
        else:
            out, _ = self.lstm(x)
        out = self.drop(out)
        return self.act(self.head(out))


def classification_loss(logits: torch.Tensor, targets: torch.Tensor,
                       pos_weight: Optional[torch.Tensor] = None,
                       mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Binary cross-entropy on logits (numerically stable).

    logits: (B, T, C), targets: (B, T, C), mask: (B, T) bool/float.
    """
    loss = nn.functional.binary_cross_entropy_with_logits(
        logits, targets, pos_weight=pos_weight, reduction="none")
    if mask is not None:
        loss = loss * mask.unsqueeze(-1)
        return loss.sum() / (mask.sum() * loss.shape[-1]).clamp(min=1.0)
    return loss.mean()


def temporal_consistency_loss(probs: torch.Tensor, mode: str = "mse",
                              mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Equation (3): MSE between adjacent window prediction vectors."""
    if probs.shape[1] < 2:
        return torch.tensor(0.0, device=probs.device, requires_grad=True)
    diff = probs[:, 1:, :] - probs[:, :-1, :]
    if mode == "mse":
        per_step = (diff ** 2).mean(dim=-1)  # (B, T-1)
    elif mode == "kl":
        p1 = probs[:, 1:, :].clamp(1e-7, 1 - 1e-7)
        p0 = probs[:, :-1, :].clamp(1e-7, 1 - 1e-7)
        per_step = (p1 * (p1.log() - p0.log())).sum(dim=-1)
    elif mode == "cosine":
        per_step = 1 - nn.functional.cosine_similarity(
            probs[:, 1:, :], probs[:, :-1, :], dim=-1)
    else:
        raise ValueError(mode)
    if mask is not None:
        m = mask[:, 1:]  # valid if target step exists
        per_step = per_step * m
        denom = m.sum().clamp(min=1.0)
        return per_step.sum() / denom
    return per_step.mean()


def joint_loss(logits: torch.Tensor, targets: torch.Tensor,
               probs: torch.Tensor, cfg: TrainConfig,
               pos_weight: Optional[torch.Tensor] = None,
               mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor,
                                                              Dict[str, float]]:
    """Equation (4): L = L_cls + lambda_tc * L_tc."""
    l_cls = classification_loss(logits, targets, pos_weight=pos_weight, mask=mask)
    l_tc = temporal_consistency_loss(probs, mode=cfg.tc_mode, mask=mask)
    total = l_cls + cfg.lambda_tc * l_tc
    return total, {"cls": float(l_cls.detach()), "tc": float(l_tc.detach())}


# ------------------------------ metrics ------------------------------
def _masked_flat(preds: torch.Tensor, targets: torch.Tensor,
                 mask: Optional[torch.Tensor] = None):
    """Flatten (B,T,C) -> (N,C) honouring the padding mask."""
    if mask is not None:
        keep = mask.bool().unsqueeze(-1).expand_as(preds)
        return preds[keep].reshape(-1, preds.shape[-1]), \
               targets[keep].reshape(-1, targets.shape[-1])
    return preds.reshape(-1, preds.shape[-1]), targets.reshape(-1, targets.shape[-1])


def compute_metrics(probs: torch.Tensor, targets: torch.Tensor,
                    threshold: float = 0.5,
                    mask: Optional[torch.Tensor] = None) -> Dict[str, float]:
    """Section 4.4 metrics, micro-averaged over valid windows."""
    preds = (probs >= threshold).float()
    p_flat, t_flat = _masked_flat(preds, targets, mask)
    pr_flat, tr_flat = _masked_flat(probs, targets, mask)
    p_np, t_np = p_flat.detach().cpu().numpy(), t_flat.detach().cpu().numpy()
    pr_np, tr_np = pr_flat.detach().cpu().numpy(), tr_flat.detach().cpu().numpy()

    # drop samples with no positive label (AP undefined) - match paper AP
    valid = tr_np.sum(axis=1) > 0
    ap = float(label_ranking_average_precision_score(
        tr_np[valid], pr_np[valid])) if valid.any() else 0.0

    return {
        "micro_f1": f1_score(t_np, p_np, average="micro", zero_division=0),
        "macro_f1": f1_score(t_np, p_np, average="macro", zero_division=0),
        "hamming_loss": hamming_loss(t_np, p_np),
        "avg_precision": ap,
    }


def decision_stability_index(preds: torch.Tensor) -> float:
    """DSI = number of dominant-label changes over the test dialogue sequence.

    Section 4.4: dominant label = argmax of probability vector per window.
    """
    dom = preds.argmax(dim=-1).cpu().numpy()  # (T,)
    return float((dom[1:] != dom[:-1]).sum())


def decision_response_latency(probs: torch.Tensor, targets: torch.Tensor,
                              threshold: float = 0.5) -> float:
    """DRL = mean windows between a true-label onset and its first correct detection.

    Section 4.4. Per-label: onset = first window where target becomes 1;
    detected = first subsequent window where pred >= threshold. Windows
    where no onset occurs are ignored.
    """
    p = (probs >= threshold).cpu().numpy()
    t = targets.cpu().numpy()
    lags: list[int] = []
    for c in range(p.shape[-1]):
        onsets = np.where(t[:, c] == 1)[0]
        for o in onsets:
            det = np.where(p[o:, c] == 1)[0]
            if len(det):
                lags.append(int(det[0]))
    return float(np.mean(lags)) if lags else float("nan")
