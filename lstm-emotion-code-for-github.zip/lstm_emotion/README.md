# LSTM-RNN Multi-Label Continuous Emotion Recognition

Reference implementation of **"LSTM-RNN-based method for multi-label learning of continuous emotional time series in robotic speech interaction"** (Decision Making and Analysis, 2026; 4(1)).

The repository contains runnable code only: model, features, training loop, baselines, metrics and plotting scripts. It does **not** contain the paper's datasets or the 20 figures; figures are regenerated from result CSVs.

## 1. What is implemented

| Module | File | Paper section |
|--------|------|---------------|
| Config (16 kHz, 25/10 ms frames, 40 Mel, 13 MFCC → 39, pYIN F0, energy, centroid/flux, prosody; 2-layer unidirectional LSTM, hidden 128, dropout 0.3, Adam 1e-3, λ=0.3) | `src/config.py` | 3.2.3, 3.2.4, 4.2, 5.3 |
| Feature extraction | `src/features.py` | 3.2.3, 4.2 |
| Time windows (2 s / 1 s hop), multi-label encoding, leave-one-session-out split | `src/dataset.py` | 3.2.2, 4.2 |
| LSTM + Sigmoid, Eq.(3) temporal-consistency loss, Eq.(4) joint loss, Micro/Macro-F1, Hamming, AP, DSI, DRL | `src/model.py` | 3.2.4–3.2.6, 4.4 |
| Training, evaluation, checkpointing, streaming `EmotionPredictor` | `src/train_eval.py` | 5 |
| Baselines: SVM, RF, MLP, CNN, LSTM, BiLSTM, CNN-LSTM, CNN-BiLSTM-Attention | `src/baselines.py` | 4.3, Table 5-1 |

## 2. Installation

```bash
pip install -r requirements.txt                 # needs PyTorch ≥ 1.12.1 (CPU build is enough)
pip install -e .                                # register the src package
```

## 3. Data

Download [IEMOCAP](https://sail.usc.edu/iemocap/) (request access), MSP-IMPROV and RAVDESS, then arrange them as:

```
data/raw/
├── IEMOCAP_full_release/Session1/.../wav/*.wav
├── MSP-IMPROV/...
└── RAVDESS/...
```

By default `Session5` is the test set (speaker-independent, leave-one-session-out), matching the reported Table 5-1.

## 4. Reproduction

```bash
# Table 5-1: train the proposed model and all baselines
python scripts/compare.py --data-root data/raw --epochs 100

# Figure 5-2(a-c) from the CSV above
python scripts/plot_fig52.py --input outputs/compare/table5_1.csv

# Figure 5-3(b): λ_tc sweep on validation Macro-F1
python scripts/train.py --data-root data/raw --sweep-lambda

# Ablation (remove multi-label / temporal consistency): edit configs/default.yaml
python scripts/train.py --data-root data/raw --lambda-tc 0

# Online inference (Section 3.6)
python examples/online_inference.py --checkpoint outputs/run/checkpoint/best.pt \
    --audio test.wav --smooth 0.3
```

## 5. Tests

```bash
python -m pytest tests -v
```

## 6. Limitations (read before uploading)

1. **No multi-label ground truth.** IEMOCAP/MSP-IMPROV/RAVDESS ship with one label per utterance. This implementation converts it to one-hot, which is only a degenerate multi-label target. The paper does not publish its multi-label annotation protocol. To reproduce Table 5-1 exactly, replace `MultiLabelEncoder.encode` and the label parsing in `dataset.py` with your own multi-label labels.
2. **Not trained on real data in this repository.** The sandbox has no PyTorch binary and no dataset access, so the model is not fitted. `tests/data/` contains 44 synthetic WAVs; `outputs/compare/table5_1.csv` contains the paper's reported numbers pasted in by hand. Uploading these figures as results would be incorrect.
3. **Paper numbers not independently reproduced.** Training on the real datasets, hyperparameter tuning and GPU experiments were not run.
4. **Minor implementation differences:**
   - Features are window-level statistics (mean/std), not frame-level sequences fed directly to the LSTM.
   - Deep semantic features (Section 3.2.3) are a placeholder; ASR/word embeddings are not included.
   - Some config values (2 s window, 1 s hop, threshold 0.5) are inferred from the paper text rather than stated as exact settings.
   - `train.py` fits the normalizer on all windows but does not re-apply it after rebuilding the datasets; set `cache_dir` and extend `WindowDataset` with `normalizer` before a real run.
5. **Missing from this release:** per-label threshold tuning, DSI/DRL table values, sentiment-shift detection, robot feedback interface (Section 3.6) and Figure 5-4/5-5 on MSP-IMPROV and RAVDESS. Contributions welcome as pull requests.

## Citation

If you use this code, please cite the paper: Jin Lu, Qin Zhou. LSTM-RNN-based method for multi-label learning of continuous emotional time series in robotic speech interaction. *Decision Making and Analysis*, 2026; 4(1).
