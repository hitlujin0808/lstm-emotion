"""Unit tests for the LSTM model, joint loss and metrics."""
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.config import ModelConfig, TrainConfig  # noqa: E402
from src.model import (LSTMEmotionModel, compute_metrics, joint_loss,
                       temporal_consistency_loss)  # noqa: E402


def test_forward_shape():
    cfg = ModelConfig(input_dim=64, hidden_dim=32, num_layers=2,
                      output_names=["neutral", "angry", "happy"])
    m = LSTMEmotionModel(cfg)
    x = torch.randn(4, 10, 64)
    lengths = torch.tensor([10, 7, 10, 5])
    p = m(x, lengths)
    assert p.shape == (4, 10, 3)
    assert torch.allclose(p.clamp(0, 1), p)


def test_loss_decreases_with_lambda():
    cfg = ModelConfig(input_dim=16, hidden_dim=16, num_layers=1,
                      output_names=["a", "b"])
    m = LSTMEmotionModel(cfg)
    x = torch.randn(8, 6, 16)
    y = torch.randint(0, 2, (8, 6, 2)).float()
    opt = torch.optim.Adam(m.parameters(), lr=1e-2)
    tcfg = TrainConfig(lambda_tc=0.3, epochs=1)
    losses = []
    for _ in range(20):
        opt.zero_grad()
        probs = m(x)
        logits = m.lstm(x)[0] if False else None  # type: ignore
        
        logits = m.head(m.drop(m.lstm(x)[0]))
        loss, _ = joint_loss(logits, y, probs, tcfg)
        loss.backward(); opt.step(); losses.append(float(loss))
    assert losses[-1] < losses[0]


def test_temporal_consistency_loss_near_zero_for_constant():
    p = torch.ones(3, 5, 4) * 0.5
    assert temporal_consistency_loss(p, mode="mse").item() == 0.0


def test_metrics_in_range():
    cfg = ModelConfig(output_names=["x", "y", "z"])
    p = torch.sigmoid(torch.randn(2, 8, 3))
    y = torch.randint(0, 2, (2, 8, 3)).float()
    m = compute_metrics(p, y, threshold=0.5)
    for k, v in m.items():
        assert 0.0 <= v <= 1.0 + 1e-6, (k, v)
    assert m["hamming_loss"] <= 1.0


def test_dsi_and_drl():
    from src.model import decision_stability_index, decision_response_latency
    p = torch.tensor([[0.9, 0.1], [0.8, 0.2], [0.1, 0.9], [0.2, 0.8]])
    assert decision_stability_index(p) == 1   # argmax: x,x,y,y -> one flip at step 2
    y = torch.tensor([[1, 0], [1, 0], [0, 1], [0, 1]], dtype=torch.float)
    lag = decision_response_latency(p, y, threshold=0.5)
    assert lag == 0.0  # both labels detected immediately
