"""Smoke-test dataset construction on the synthetic fixtures."""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.config import AudioConfig, DataConfig  # noqa: E402
from src.dataset import (MultiLabelEncoder, WindowDataset, collate_padded,
                         window_dataset_from_files)  # noqa: E402
from src.features import FeatureExtractor, WindowNormalizer  # noqa: E402

FIX = os.path.join(os.path.dirname(__file__), "data")


def _extractor():
    return FeatureExtractor(AudioConfig(), use_deep=False)


def test_encoder_roundtrip():
    enc = MultiLabelEncoder.default()
    assert enc.n_classes == 10
    y = enc.encode("angry")
    assert y[enc.idx["angry"]] == 1.0
    assert y.sum() == 1.0
    assert "angry" in enc.decode(y, 0.5)


def test_window_dataset_shapes():
    ext = _extractor()
    files = [os.path.join(FIX, "train", f) for f in sorted(os.listdir(
        os.path.join(FIX, "train")))][:4]
    ds = window_dataset_from_files(files, ext, window_s=2.0, hop_s=1.0)
    assert len(ds) == 4
    X, Y, L = ds[0]
    assert X.dim() == 2 and Y.dim() == 2
    assert X.shape[0] == L
    assert Y.shape[-1] == 10
    assert X.shape[1] == ext.out_dim


def test_collate_padded():
    ext = _extractor()
    files = [os.path.join(FIX, "val", f) for f in sorted(os.listdir(
        os.path.join(FIX, "val")))]
    ds = window_dataset_from_files(files, ext, window_s=2.0, hop_s=1.0)
    batch = [ds[i] for i in range(len(ds))]
    Xp, Yp, lengths = collate_padded(batch)
    assert Xp.shape[0] == len(batch)
    assert Xp.shape[2] == ext.out_dim
    assert lengths.sum() == sum(b[0].shape[0] for b in batch)


def test_normalizer_state_roundtrip():
    ext = _extractor()
    feats = [ext.from_audio(np.random.randn(16000).astype(np.float32))
             for _ in range(20)]
    n = WindowNormalizer.fit_normalizer(feats)
    arr = np.array(feats)
    normed = n(arr)
    assert np.allclose(normed.mean(0), 0, atol=1e-6)
    restored = WindowNormalizer.from_state_dict(n.state_dict())
    assert np.allclose(restored(arr), normed)
