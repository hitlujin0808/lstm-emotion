#!/usr/bin/env python3
"""Online / streaming emotion inference demo (Section 3.6).

Reads an audio file (or microphone stream), cuts it into 2 s windows with
1 s hop, prints the multi-label probability vector per window and applies
optional exponential smoothing.

Usage:
    python examples/online_inference.py --checkpoint outputs/run/checkpoint/best.pt \\
        --audio my_speech.wav --smooth 0.3
"""
import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.config import Config  # noqa: E402
from src.features import Extractor, WindowNormalizer  # noqa: E402
from src.model import LSTMEmotionModel  # noqa: E402
from src.train_eval import EmotionPredictor  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--audio", required=True, help="WAV file to analyse")
    ap.add_argument("--data-root", default=None,
                    help="Dataset root; only used to locate normalizer.json")
    ap.add_argument("--window", type=float, default=2.0)
    ap.add_argument("--hop", type=float, default=1.0)
    ap.add_argument("--smooth", type=float, default=0.0,
                    help="Exponential-smoothing alpha (Section 3.2.6)")
    ap.add_argument("--threshold", type=float, default=None)
    ap.add_argument("--jsonl", default=None,
                    help="Append per-window JSON lines to this file")
    args = ap.parse_args()

    ck = torch.load(args.checkpoint, map_location="cpu")
    cfg = Config.from_dict(ck["config"]) if isinstance(ck["config"], dict) \
        else Config()
    if args.threshold is not None:
        cfg.model.threshold = args.threshold

    extractor = FeatureExtractor(cfg.audio)
    cfg.model.input_dim = extractor.out_dim
    model = LSTMEmotionModel(cfg.model)
    model.load_state_dict(ck["model_state"])

    # normalizer
    norm_dir = cfg.data.cache_dir
    if args.data_root:
        cand = os.path.join(args.data_root, "data", "processed",
                            "normalizer.json")
        if os.path.exists(cand):
            norm_dir = os.path.dirname(cand)
    np_ = json.load(open(os.path.join(norm_dir, "normalizer.json"))) \
        if os.path.exists(os.path.join(norm_dir, "normalizer.json")) else None
    normalizer = WindowNormalizer.from_state_dict(np_) if np_ else None

    pred = EmotionPredictor(model, normalizer, extractor, cfg,
                            smooth_alpha=args.smooth)

    import librosa
    y, _ = librosa.load(args.audio, sr=cfg.audio.sample_rate, mono=True)
    sr = cfg.audio.sample_rate
    start = 0.0
    out_f = open(args.jsonl, "a") if args.jsonl else None
    try:
        while start < len(y) / sr:
            end = min(start + args.window, len(y) / sr)
            seg = y[int(start * sr):int(end * sr)]
            if len(seg) < 0.1 * sr:
                break
            probs = pred.predict_window(seg)
            labels = pred.predict_labels(probs)
            row = {"t_start": round(start, 3), "t_end": round(end, 3),
                   "probabilities": probs, "active_labels": labels}
            print(f"[{row['t_start']:.2f}-{row['t_end']:.2f}] " +
                  ", ".join(f"{k}={v:.3f}" for k, v in probs.items()
                            if v >= cfg.model.threshold))
            if out_f:
                out_f.write(json.dumps(row) + "\n")
            start += args.hop
            if end >= len(y) / sr:
                break
    finally:
        if out_f:
            out_f.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
