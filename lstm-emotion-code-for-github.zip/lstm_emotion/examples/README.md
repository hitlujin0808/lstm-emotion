# Examples

Two executable notebooks walk through the reference implementation end to end.

| Notebook | What it does | Section |
|----------|-------------|---------|
| [`01_train_and_evaluate.ipynb`](01_train_and_evaluate.ipynb) | Build windowed features on IEMOCAP, fit the normalizer on the training split, train with `train()`, run Table-5-1 metrics, reproduce the λ sweep of Figure 5-3(b) | 4.2, 5.1, 5.3 |
| [`02_online_inference.ipynb`](02_online_inference.ipynb) | Load a checkpoint, slide a 2 s / 1 s window over a WAV, apply exponential smoothing (Section 3.2.6), emit a per-window JSONL plus a matplotlib trajectory plot | 3.6 |

Run them after installing the package:

```bash
pip install -e .              # from the repo root
pip install notebook          # or jupyterlab
jupyter notebook examples/
```

Both notebooks default to the synthetic fixtures under `tests/data/` when
`--data-root` is not set, so they run in seconds without any dataset download.

A third, shorter example is the CLI:

```bash
python examples/online_inference.py \
    --checkpoint outputs/run/checkpoint/best.pt \
    --audio my_speech.wav --smooth 0.3 --jsonl trajectory.jsonl
```
