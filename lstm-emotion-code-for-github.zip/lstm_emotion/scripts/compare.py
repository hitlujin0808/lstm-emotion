#!/usr/bin/env python3
"""Reproduce Table 5-1 comparisons.

Trains/evaluates every baseline from Section 4.3 plus the proposed model
under identical data splits and reports Micro-F1, Macro-F1, Hamming Loss
and Average Precision.

Usage:
    python scripts/compare.py --data-root tests/data --epochs 6
"""
import argparse
import csv
import os
import sys

import numpy as np
import torch
import torch.optim as optim
from sklearn.metrics import f1_score, hamming_loss, label_ranking_average_precision_score

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.baselines import SklearnBaseline, make_baseline  # noqa: E402
from src.config import Config  # noqa: E402
from src.dataset import WindowDataset, window_dataset_from_files, make_splits  # noqa: E402
from src.features import Extractor  # noqa: E402
from src.model import LSTMEmotionModel, compute_metrics  # noqa: E402
from src.train_eval import train, evaluate  # noqa: E402


def _collate(batch):
    return (torch.cat([i[0] for i in batch]),
            torch.cat([i[1] for i in batch]),
            torch.tensor([i[2] for i in batch]))


def evaluate_baseline(name, model, ds, cfg, device):
    if name in ("svm", "rf", "mlp"):
        proba = model.predict_proba(ds)
        Yf = model._flat(ds)[1].astype(int)
    else:
        model.eval()
        Pf, Yf = [], []
        for X, Y, L in torch.utils.data.DataLoader(ds, batch_size=32,
                                                   collate_fn=_collate):
            X, Y = X.to(device), Y.to(device)
            with torch.no_grad():
                p = model(X, L)
            if p.ndim == 3 and p.shape[1] > 1 and name != "ours":
                p = p.mean(dim=1)  # collapse time -> one vector per utterance
            Pf.append(p.cpu())
            Yf.append(Y.cpu())
        proba = torch.cat(Pf).numpy()
        Yf = torch.cat(Yf).numpy().astype(int)
        if proba.ndim == 3:
            proba = proba.reshape(-1, proba.shape[-1])
            Yf = Yf.reshape(-1, Yf.shape[-1])

    preds = (proba >= cfg.model.threshold).astype(int)
    valid = Yf.sum(axis=1) > 0
    ap = float(label_ranking_average_precision_score(Yf[valid], proba[valid])) \
        if valid.any() else 0.0
    return {
        "model": name,
        "micro_f1": f1_score(Yf, preds, average="micro", zero_division=0),
        "macro_f1": f1_score(Yf, preds, average="macro", zero_division=0),
        "hamming_loss": hamming_loss(Yf, preds),
        "avg_precision": ap,
    }


def train_deep(model, cfg, train_ds, val_ds, test_ds, device):
    model.to(device)
    opt = optim.Adam(model.parameters(), lr=cfg.train.lr)
    loader = torch.utils.data.DataLoader(train_ds, batch_size=cfg.train.batch_size,
                                         collate_fn=_collate)
    for _ in range(cfg.train.epochs):
        model.train()
        for X, Y, L in loader:
            X, Y = X.to(device), Y.to(device)
            opt.zero_grad()
            p = model(X, L)
            if p.ndim == 3:  # time-distributed baselines: mean-pool target
                loss = torch.nn.functional.binary_cross_entropy(
                    p, Y.expand_as(p))
            else:
                loss = torch.nn.functional.binary_cross_entropy(p, Y)
            loss.backward(); opt.step()
    model.eval()
    return evaluate_baseline("tmp", model, test_ds, cfg, device)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--models", default="svm,rf,mlp,cnn,lstm,bilstm,"
                                        "cnn-lstm,cnn-bilstm-attention,ours")
    ap.add_argument("--config", default=None)
    ap.add_argument("--device", default="auto")
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--output", default="outputs/compare/table5_1.csv")
    args = ap.parse_args()
    models = [m.strip() for m in args.models.split(",")]

    cfg = Config()
    if args.config:
        import yaml  # type: ignore
        cfg = Config.from_dict(yaml.safe_load(open(args.config)))
    cfg.data.root = args.data_root
    if args.epochs: cfg.train.epochs = args.epochs
    if cfg.data.device == "auto":  # noqa: no cover
        pass
    device = "cuda" if torch.cuda.is_available() and args.device != "cpu" \
        else "cpu"

    extractor = FeatureExtractor(cfg.audio)
    cfg.model.input_dim = extractor.out_dim
    mk = lambda files: window_dataset_from_files(files, extractor,
                                                cfg.data.window_s,
                                                cfg.data.window_hop_s)
    train_ds, val_ds, test_ds = mk(make_splits(cfg.data)[0]), \
        mk(make_splits(cfg.data)[1]), mk(make_splits(cfg.data)[2])

    rows = []
    for name in models:
        print(f"\n--- {name} ---")
        if name in ("svm", "rf", "mlp"):
            m = SklearnBaseline(name); m.fit(train_ds)
            row = evaluate_baseline(name, m, test_ds, cfg, device)
        elif name == "ours":
            m = train(cfg, train_ds, val_ds, device=device,
                      checkpoint_dir=os.path.join(args.output, "..", "ours"))
            row = evaluate(m, test_ds, cfg, device)
            row["model"] = "ours"
        else:
            m = make_baseline(name, extractor.out_dim,
                              len(cfg.model.output_names))
            row = train_deep(m, cfg, train_ds, val_ds, test_ds, device)
            row["model"] = name
        rows.append(row)
        print("  " + "  ".join(f"{k}={v:.4f}" if isinstance(v, float)
                              else f"{k}={v}" for k, v in row.items()))

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["model", "micro_f1", "macro_f1",
                                         "hamming_loss", "avg_precision"])
        w.writeheader(); w.writerows(rows)
    print(f"\nSaved: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
