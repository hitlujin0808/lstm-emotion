#!/usr/bin/env python3
"""Evaluate a trained checkpoint and print Table 5-1 style metrics.

Usage:
    python scripts/evaluate.py --checkpoint outputs/run/checkpoint/best.pt \\
        --data-root /path/to/IEMOCAP_full_release --split test
"""
import argparse
import json
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.config import Config  # noqa: E402
from src.dataset import window_dataset_from_files, make_splits  # noqa: E402
from src.features import Extractor, WindowNormalizer  # noqa: E402
from src.model import LSTMEmotionModel  # noqa: E402
from src.train_eval import evaluate as eval_fn  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--split", default="test", choices=["train", "val", "test"])
    ap.add_argument("--device", default="auto")
    ap.add_argument("--threshold", type=float, default=None)
    ap.add_argument("--output", default=None)
    args = ap.parse_args()

    ck = torch.load(args.checkpoint, map_location="cpu")
    cfg = Config.from_dict(ck["config"]) if isinstance(ck["config"], dict) \
        else Config()
    cfg.data.root = args.data_root
    extractor = FeatureExtractor(cfg.audio)
    cfg.model.input_dim = extractor.out_dim

    train_f, val_f, test_f = make_splits(cfg.data)
    files = {"train": train_f, "val": val_f, "test": test_f}[args.split]
    norm_path = os.path.join(cfg.data.cache_dir, "normalizer.json")
    normalizer = WindowNormalizer.from_state_dict(json.load(open(norm_path))) \
        if os.path.exists(norm_path) else None
    ds = window_dataset_from_files(files, extractor, cfg.data.window_s,
                                  cfg.data.window_hop_s, normalizer)

    model = LSTMEmotionModel(cfg.model)
    model.load_state_dict(ck["model_state"])
    th = args.threshold if args.threshold is not None else cfg.model.threshold
    metrics = eval_fn(model, ds, cfg, args.device, threshold=th)

    print(f"\n=== {args.split.upper()}  (threshold={th}) ===")
    print(f"{'metric':<18}{'value':>12}")
    print("-" * 32)
    names = [("Micro-F1", "micro_f1"), ("Macro-F1", "macro_f1"),
             ("Hamming Loss", "hamming_loss"),
             ("1-Hamming Loss", lambda m: 1 - m["hamming_loss"]),
             ("Avg Precision", "avg_precision"),
             ("DSI (decision stability)", "dsi"),
             ("DRL (decision latency)", "drl")]
    out = {}
    for label, key in names:
        v = key(metrics) if callable(key) else metrics[key]
        out[label] = v
        print(f"{label:<18}{v:>12.4f}")

    if args.output:
        json.dump({"split": args.split, "threshold": th, **out},
                  open(args.output, "w"), indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
