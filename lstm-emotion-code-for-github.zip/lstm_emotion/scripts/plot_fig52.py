#!/usr/bin/env python3
"""Recreate Figure 5-2(a-c) from a comparison CSV (Table 5-1 output).

Reads outputs/compare/table5_1.csv and writes:
    figures/fig5-2a_scatter.png   Micro-F1 vs Macro-F1 (size = Avg Precision)
    figures/fig5-2b_line.png      4 metrics line chart (Hamming -> 1-Hamming)
    figures/fig5-2c_radar.png     radar chart

Usage:
    python scripts/plot_fig52.py --input outputs/compare/table5_1.csv
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["font.sans-serif"] = ["WenQuanYi Micro Hei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

MODEL_ORDER = ["SVM", "Random Forest", "MLP", "CNN", "LSTM", "BiLSTM",
               "CNN-LSTM", "CNN-BiLSTM-Attention", "Ours"]


def load(path):
    import csv
    rows = {r["model"].lower(): r for r in csv.DictReader(open(path))}
    out = []
    for m in MODEL_ORDER:
        key = next((k for k in rows if k.lower() in (m.lower(), m.lower().replace(" ", ""),
                                                     "ours" if m == "Ours" else "")), None)
        if key:
            out.append((m, rows[key]))
    return out


def fig5_2a(data, outdir):
    fig, ax = plt.subplots(figsize=(8, 6))
    for m, r in data:
        ax.scatter(float(r["micro_f1"]) * 100, float(r["macro_f1"]) * 100,
                   s=float(r["avg_precision"]) * 300 + 40,
                   alpha=0.65, edgecolor="k", linewidth=1.2, label=m)
    ax.axvline(65, ls="--", c="grey", lw=0.8); ax.axhline(65, ls="--", c="grey", lw=0.8)
    ax.set_xlabel("Micro-F1 (%)"); ax.set_ylabel("Macro-F1 (%)")
    ax.set_title("Figure 5-2(a). Micro-F1 vs Macro-F1 (marker size = Avg Precision)")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "fig5-2a_scatter.png"), dpi=200)
    plt.close(fig)


def fig5_2b(data, outdir):
    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(data))
    metrics = [("micro_f1", "Micro-F1"), ("macro_f1", "Macro-F1"),
               ("avg_precision", "Average Precision"),
               (None, "1-Hamming Loss")]
    for key, label in metrics:
        if key is None:
            y = [1 - float(r["hamming_loss"]) for _, r in data]
        else:
            y = [float(r[key]) for _, r in data]
        ax.plot(x, np.array(y) * 100, marker="o", ms=4, label=label)
    ax.set_xticks(x); ax.set_xticklabels([m for m, _ in data], rotation=30, ha="right")
    ax.set_ylabel("Score (%)"); ax.set_ylim(40, 100)
    ax.set_title("Figure 5-2(b). Four evaluation metrics across models")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "fig5-2b_line.png"), dpi=200)
    plt.close(fig)


def fig5_2c(data, outdir):
    labels = ["Micro-F1", "Macro-F1", "Avg Precision", "1-Hamming Loss"]
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    angles += angles[:1]
    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw=dict(polar=True))
    for m, r in data:
        vals = [float(r["micro_f1"]), float(r["macro_f1"]),
                float(r["avg_precision"]), 1 - float(r["hamming_loss"])]
        vals += vals[:1]
        ax.plot(angles, vals, label=m, lw=1.5)
        ax.fill(angles, vals, alpha=0.08)
    ax.set_xticks(angles[:-1]); ax.set_xticklabels(labels)
    ax.set_ylim(0, 1); ax.set_title("Figure 5-2(c). Radar chart of overall performance",
                                   pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1), fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "fig5-2c_radar.png"), dpi=200)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="outputs/compare/table5_1.csv")
    ap.add_argument("--output-dir", default="figures")
    args = ap.parse_args()
    data = load(args.input)
    os.makedirs(args.output_dir, exist_ok=True)
    fig5_2a(data, args.output_dir)
    fig5_2b(data, args.output_dir)
    fig5_2c(data, args.output_dir)
    print("Wrote figures: fig5-2a/b/c in", args.output_dir)


if __name__ == "__main__":
    main()
