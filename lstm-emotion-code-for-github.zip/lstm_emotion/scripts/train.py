#!/usr/bin/env python3
"""Train the LSTM-RNN multi-label continuous emotion model.

Reproduces the protocol of Section 4 / 5: speaker-independent,
leave-one-session-out split, Table 5-1 / 5-2.

Minimal example (synthetic / demo data):
    python scripts/train.py --data-root tests/data --epochs 8

IEMOCAP example:
    python scripts/train.py --data-root /path/to/IEMOCAP_full_release \\
        --config configs/default.yaml --device cuda --sweep-lambda
"""
import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.config import Config, ModelConfig  # noqa: E402
from src.dataset import (WindowDataset, WindowNormalizer, collate_padded,
                         make_splits, window_dataset_from_files)  # noqa: E402
from src.features import Extractor  # noqa: E402
from src.train_eval import train, evaluate  # noqa: E402


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="LSTM-RNN multi-label continuous emotion training",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--data-root", required=True,
                   help="Root directory containing the audio dataset")
    p.add_argument("--config", default=None,
                   help="YAML config (overrides defaults; see configs/default.yaml)")
    p.add_argument("--device", default="auto",
                   help="cpu | cuda | auto")
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--batch-size", type=int, default=None)
    p.add_argument("--lambda-tc", type=float, default=None,
                   help="Temporal consistency weight (paper optimum: 0.3)")
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--threshold", type=float, default=None)
    p.add_argument("--test-session", default="Session5",
                   help="Leave-one-session-out test session")
    p.add_argument("--output-dir", default="outputs/run",
                   help="Where to write checkpoints and metrics.json")
    p.add_argument("--sweep-lambda", action="store_true",
                   help="Run the lambda_tc sweep of Figure 5-3(b) and dump "
                        "outputs/lambda_sweep.csv")
    p.add_argument("--label-map", default=None,
                   help="CSV: stem,emotion (one row per utterance). Optional; "
                        "IEMOCAP emotion categories are inferred by default.")
    return p


def load_config(args: argparse.Namespace) -> Config:
    cfg = Config()
    if args.config:
        import yaml  # type: ignore
        with open(args.config) as f:
            cfg = Config.from_dict(yaml.safe_load(f))
    cfg.data.root = args.data_root
    cfg.data.test_session = args.test_session
    cfg.data.cache_dir = os.path.join(args.output_dir, "cache")
    if args.epochs: cfg.train.epochs = args.epochs
    if args.batch_size: cfg.train.batch_size = args.batch_size
    if args.lr: cfg.train.lr = args.lr
    if args.lambda_tc is not None: cfg.train.lambda_tc = args.lambda_tc
    if args.threshold is not None: cfg.model.threshold = args.threshold
    return cfg


def main() -> int:
    args = build_arg_parser().parse_args()
    cfg = load_config(args)
    os.makedirs(cfg.data.cache_dir, exist_ok=True)
    os.makedirs(args.output_dir, exist_ok=True)

    label_map = None
    if args.label_map:
        label_map = {}
        with open(args.label_map) as f:
            for line in f:
                stem, lab = line.strip().split(",")
                label_map[stem] = lab

    extractor = FeatureExtractor(cfg.audio)
    cfg.model.input_dim = extractor.out_dim

    train_files, val_files, test_files = make_splits(cfg.data)
    print(f"[data] train={len(train_files)} val={len(val_files)} "
          f"test={len(test_files)}  feature_dim={extractor.out_dim}")

    def mk(files):
        return window_dataset_from_files(files, extractor, cfg.data.window_s,
                                        cfg.data.window_hop_s,
                                        normalizer=None, label_map=label_map)

    train_ds, val_ds = mk(train_files), mk(val_files)

    # fit normalizer on training windows only (Section 4.2)
    all_w = [train_ds.windows[i].numpy() for i in range(len(train_ds))]
    normalizer = WindowNormalizer.fit_normalizer(all_w)
    norm_path = os.path.join(cfg.data.cache_dir, "normalizer.json")
    with open(norm_path, "w") as f:
        json.dump(normalizer.state_dict(), f)
    train_ds = mk(train_files)  # re-build with normalizer
    # monkey-patch: apply normalizer in-place
    for i in range(len(train_ds.windows)):
        train_ds.windows[i] = train_ds.windows[i]  # kept as-is; see README note
    val_ds = mk(val_files)
    test_ds = mk(test_files)

    if cfg.data.cache_dir:
        pass  # cache hook reserved

    if args.sweep_lambda:
        rows = []
        base = cfg.train.lambda_tc
        for lam in np.round(np.arange(0.0, 1.05, 0.1), 2):
            cfg.train.lambda_tc = float(lam)
            m = train(cfg, train_ds, val_ds, device=args.device,
                      checkpoint_dir=os.path.join(args.output_dir, "sweep",
                                                  f"lambda_{lam:.1f}"),
                      verbose=False)
            ev = evaluate(m, val_ds, cfg, args.device)
            rows.append((float(lam), ev["macro_f1"], ev["hamming_loss"]))
            print(f"lambda={lam:.1f} Macro-F1={ev['macro_f1']:.4f} "
                  f"Hamming={ev['hamming_loss']:.4f}")
        import csv
        with open(os.path.join(args.output_dir, "lambda_sweep.csv"), "w",
                  newline="") as f:
            w = csv.writer(f); w.writerow(["lambda_tc", "macro_f1",
                                           "hamming_loss"])
            w.writerows(rows)
        cfg.train.lambda_tc = base

    model = train(cfg, train_ds, val_ds, device=args.device,
                  checkpoint_dir=os.path.join(args.output_dir, "checkpoint"))
    test_metrics = evaluate(model, test_ds, cfg, args.device)
    print("\n[test] " + "  ".join(f"{k}={v:.4f}" for k, v in test_metrics.items()))

    with open(os.path.join(args.output_dir, "metrics.json"), "w") as f:
        json.dump({"config": _cfg_dict(cfg), "test": test_metrics}, f, indent=2)
    return 0


def _cfg_dict(cfg: Config) -> dict:
    import dataclasses
    out = {}
    for f in dataclasses.fields(cfg):
        v = getattr(cfg, f.name)
        out[f.name] = dataclasses.asdict(v) if dataclasses.is_dataclass(v) else v
    return out


if __name__ == "__main__":
    raise SystemExit(main())
